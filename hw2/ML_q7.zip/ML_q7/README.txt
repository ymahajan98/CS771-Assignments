Put the code in the same folder as the txt files.
Run python classification.py
Images a1,a2,a3 are for the first dataset and a4,a5,a6 for the second dataset.
